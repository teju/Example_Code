package com.applozic.mobicommons.commons.image;

public class BitmapDecodingException extends Throwable {
    public BitmapDecodingException(String s) {
        super(s);
    }
}
