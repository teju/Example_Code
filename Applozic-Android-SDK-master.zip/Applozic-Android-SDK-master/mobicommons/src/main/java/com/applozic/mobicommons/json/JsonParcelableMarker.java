package com.applozic.mobicommons.json;

import android.os.Parcelable;

/**
 * Created by sunil on 2/6/16.
 */
abstract public class JsonParcelableMarker implements Parcelable {
}
