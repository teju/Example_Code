package com.applozic.mobicommons.emoticon;

import android.content.Context;
import android.text.Spannable;

/**
 * Created by adarsh on 11/4/15.
 */
public interface EmojiconHandler {
    void addEmojis(Context context, Spannable spannable, int i);
}
