package com.applozic.mobicommons.people;

/**
 * Created by devashish on 20/11/14.
 */
public interface SearchListFragment {

    boolean onQueryTextChange(String newText);

}