package com.applozic.mobicomkit;

import android.os.Build;

public class GeneralConstants {


}
