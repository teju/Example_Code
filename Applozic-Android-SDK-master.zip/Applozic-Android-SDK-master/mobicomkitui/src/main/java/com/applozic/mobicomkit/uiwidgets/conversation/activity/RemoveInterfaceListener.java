package com.applozic.mobicomkit.uiwidgets.conversation.activity;

/**
 * Created by Sunil on 12/28/2016.
 */

public interface RemoveInterfaceListener {

    void removeCallBack();

}
