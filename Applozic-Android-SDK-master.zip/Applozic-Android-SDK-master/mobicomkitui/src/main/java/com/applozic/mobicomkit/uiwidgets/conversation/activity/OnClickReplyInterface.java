package com.applozic.mobicomkit.uiwidgets.conversation.activity;

import com.applozic.mobicomkit.api.conversation.Message;

/**
 * Created by ninu on 10/04/17.
 */

public interface OnClickReplyInterface {
    void onClickOnMessageReply(Message message);
}
