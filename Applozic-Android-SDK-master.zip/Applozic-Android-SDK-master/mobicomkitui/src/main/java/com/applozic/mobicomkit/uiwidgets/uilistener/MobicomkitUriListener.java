package com.applozic.mobicomkit.uiwidgets.uilistener;

import android.net.Uri;

/**
 * Created by devashish on 16/07/16.
 */
public interface MobicomkitUriListener {

    Uri getCurrentImageUri();
}
