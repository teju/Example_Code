/*
 * Created by Itzik Braun on 2/4/2015.
 * Copyright (c) 2015 deluge. All rights reserved.
 *
 * Last Modification at: 4/2/15 3:01 PM
 */

package com.countrypicker;

import android.app.Application;
import android.test.ApplicationTestCase;

/**
 * <a href="http://d.android.com/tools/testing/testing_android.html">Testing Fundamentals</a>
 */
public class ApplicationTest extends ApplicationTestCase<Application> {
    public ApplicationTest() {
        super(Application.class);
    }
}