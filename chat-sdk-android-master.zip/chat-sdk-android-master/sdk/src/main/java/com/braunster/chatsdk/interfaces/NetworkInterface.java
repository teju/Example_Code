/*
 * Created by Itzik Braun on 12/3/2015.
 * Copyright (c) 2015 deluge. All rights reserved.
 *
 * Last Modification at: 3/12/15 4:27 PM
 */

package com.braunster.chatsdk.interfaces;

/**
 * Created by itzik on 6/8/2014.
 */
public interface NetworkInterface {

//    /** Syncing the user details. first try to retrieve the user from the Local DB and then gather more data from the user FB Profile.*/
//    public  void syncWithProgress(CompletionListener completionListener);
//
//    /** Get user facebook friends, Calls The FBManager for preforming the fetch friends task.*/
//    public void getFriendsListWithListener(CompletionListener completionListener);
//
//    /** ASK I have no idea what is id<PUser> stands for.*/
//    public BUser currentUser();
//
//    /** Send message by given data stored in the BMessage Obj.*/
//    public void sendMessage(BMessage message, CompletionListener completionListener);
//
//    /** Create a new messaged thread with the given users as participants.*/ // ASK Is this private or public ?
//    public void createThreadWithUsers(ArrayList<BUser> users, CompletionListener completionListener);
//
//    /** Create a public thread for given name.*/
//    public void createPublicThreadWithName(String name, CompletionListener completionListener);
//
//    /** Set the last time the user has been online.*/
//    public void setLastOnline(Date lastOnline);
//
//    /** Delete thread for given id.*/
//    public void deleteThreadWithEntityID(String entityId, CompletionListener completionListener);
//
//    /** Delete thread by given BThread Obj given.*/
//    public void deleteThread(BThread thread, CompletionListener completionListener);
//
//    /** Set a listener that will notify the registered class each time a thread or a message is added. */
//    public void setNewDataListener(ActivityListener newDataListener);
//
//    public String serverURL();
//
//    /** Send text message.*/
//    public void sendMessageWithText(String text, String threadEntityId, CompletionListener completionListener);
//
//    /** Send message with an image.*/
//    public void sendMessageWithImage(ImageView imageView, String threadEntityId, CompletionListener completionListener);
//
//    /**@see "http://developer.android.com/guide/topics/location/strategies.html"
//     * Send user location.*/
//    public void sendMessageWithLocation(LocationManager locationManager, String threadEntityId, CompletionListener completionListener);
//
//    /** Save user data to the local database*/
//    public void save();
//
//    /** Get all messages for given thread id ordered Ascending/Descending*/
//    public ArrayList<BMessage> getMessagesForThreadForEntityID(String entityId);

}
