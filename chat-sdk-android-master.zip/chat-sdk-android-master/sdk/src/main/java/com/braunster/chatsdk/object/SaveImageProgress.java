/*
 * Created by Itzik Braun on 17/3/2015.
 * Copyright (c) 2015 deluge. All rights reserved.
 *
 * Last Modification at: 3/17/15 10:05 AM
 */

package com.braunster.chatsdk.object;

import android.graphics.Bitmap;

public class SaveImageProgress {
        public String dimensionsString;
        public Bitmap savedImage;
        public Bitmap savedImageThumbnail;
}