

package com.braunster.chatsdk.thread;

public interface PausableThreadExecutor{
    public void pause();

    public void resume();
}
