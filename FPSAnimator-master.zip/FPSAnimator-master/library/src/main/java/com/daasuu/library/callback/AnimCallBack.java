package com.daasuu.library.callback;

/**
 * Created by a12511 on 15/12/21.
 */
public interface AnimCallBack {
    void call();
}
