[![Android Arsenal](https://img.shields.io/badge/Android%20Arsenal-SpannableTextview-brightgreen.svg?style=flat)](http://android-arsenal.com/details/1/1978)

# SpannableTextview
Spannable Textview in Android is mostly
used to customize the styles for a single
TextView(i.e., styles,size,color) rather creating a seperate layout.

![spannabletextview](https://cloud.githubusercontent.com/assets/11768239/8147596/630a1ea4-1290-11e5-8eff-569473f8d3d1.png)

For tutorial, Please visit my blog http://takeoffandroid.com/uncategorized/android-spannable-text-view-to-change-color-size-style-and-adding-click-event-for-particular-word/




