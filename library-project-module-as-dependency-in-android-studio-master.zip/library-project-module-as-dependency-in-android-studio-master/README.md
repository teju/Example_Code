# library-project-module-as-dependency-in-android-studio

You can find complete Library-Project/Module as Dependency in Android Studio here [Library-Project/Module as Dependency in Android Studio](http://www.theappguruz.com/blog/library-project-module-as-dependency-in-android-studio).

This Tutorial has been presented by The App Guruz - One of the best [Android App Development Company in India](http://www.theappguruz.com/android-app-development/)
