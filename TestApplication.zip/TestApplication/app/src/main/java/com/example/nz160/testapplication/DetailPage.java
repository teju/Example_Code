package com.example.nz160.testapplication;

import android.annotation.TargetApi;
import android.app.Activity;
import android.app.Fragment;
import android.app.FragmentManager;
import android.content.Context;
import android.os.Build;
import android.os.Bundle;
import android.support.design.widget.CoordinatorLayout;
import android.support.design.widget.TabLayout;
import android.support.v13.app.FragmentPagerAdapter;
import android.support.v13.app.FragmentStatePagerAdapter;
import android.support.v4.view.PagerAdapter;
import android.support.v4.view.ViewPager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

public class DetailPage extends Activity implements ViewPager.OnPageChangeListener{

    private android.support.v4.view.ViewPager viewPager;
    private ViewPager viewpager_detail;

    @TargetApi(Build.VERSION_CODES.M)

    public DetailPage(){

    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.content_main);
        viewpager_detail = (ViewPager)findViewById(R.id.viewpager);
        DetailPagerAdapter mAdapter = new DetailPagerAdapter(this,getFragmentManager());
        viewpager_detail.setAdapter(mAdapter);
    }

    @Override
    public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {}

    @Override
    public void onPageSelected(int position) {
        viewpager_detail.setSelected(true);
    }

    @Override
    public void onPageScrollStateChanged(int state) {}
}

class MyDetailAdapter extends FragmentStatePagerAdapter {

    private final List<Fragment> mFragmentList = new ArrayList<>();
    private final List<String> mFragmentTitleList = new ArrayList<>();

    public MyDetailAdapter(FragmentManager fm) {
        super(fm);
    }

    @Override
    public Fragment getItem(int position) {
        System.out.println("mFragmentList " + position);
        return mFragmentList.get(position);
    }

    @Override
    public int getCount() {
        return mFragmentList.size();
    }

    public void addFragment(Fragment fragment, String title) {
        mFragmentList.add(fragment);
        mFragmentTitleList.add(title);
    }

    @Override
    public CharSequence getPageTitle(int position) {
        return mFragmentTitleList.get(position);
    }
}
    class DetailPagerAdapter extends PagerAdapter implements ViewPager.OnPageChangeListener {

        private final FragmentManager fragmentManager;
        private Context mContext;
        ;
        private ViewPager viewPager;
        private TabLayout tabhost;

        public DetailPagerAdapter(Context mContext, FragmentManager fragmentManager) {
            this.mContext = mContext;
            this.fragmentManager = fragmentManager;
        }

        @Override
        public int getCount() {
            return 3;
        }

        @Override
        public boolean isViewFromObject(View view, Object object) {
            return view == ((CoordinatorLayout) object);
        }

        @Override
        public Object instantiateItem(ViewGroup container, int position) {
            View itemView = LayoutInflater.from(mContext).inflate(R.layout.activity_main2, container, false);

            initTabHost(itemView);

            TextView textview = (TextView) itemView.findViewById(R.id.titel_box_text);
            textview.setText("GlobalCompliance For All");
            container.addView(itemView);

            return itemView;
        }

        private void initTabHost(View rootView) {
            viewPager = (ViewPager) rootView.findViewById(R.id.viewpager);
            MyDetailAdapter adapter = new MyDetailAdapter(fragmentManager);
            adapter.addFragment(new Fragment1(), "ONE");
            adapter.addFragment(new Fragment2(), "TWO");
            adapter.addFragment(new Fragment3(), "Three");
            viewPager.setCurrentItem(0);
            viewPager.setAdapter(adapter);
            viewPager.setOnPageChangeListener(this);

            tabhost = (TabLayout) rootView.findViewById(R.id.tabs);
            tabhost.setupWithViewPager(viewPager);

            tabhost.setOnTabSelectedListener(new TabLayout.ViewPagerOnTabSelectedListener(viewPager) {
                @Override
                public void onTabSelected(TabLayout.Tab tab) {
                    viewPager.setCurrentItem(tabhost.getSelectedTabPosition());

                }

                @Override
                public void onTabUnselected(TabLayout.Tab tab) {
                    tab.getCustomView();
                }
            });
        }

        @Override
        public void destroyItem(ViewGroup container, int position, Object object) {
            container.removeView((CoordinatorLayout) object);
        }

        @Override
        public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {
        }

        @Override
        public void onPageSelected(int position) {
            tabhost.setSelected(true);
        }

        @Override
        public void onPageScrollStateChanged(int state) {
        }
    }
