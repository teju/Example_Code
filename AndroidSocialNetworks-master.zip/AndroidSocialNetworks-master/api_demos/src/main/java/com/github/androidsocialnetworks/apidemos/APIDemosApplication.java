package com.github.androidsocialnetworks.apidemos;

import android.app.Application;

public class APIDemosApplication extends Application {

    public static final String TAG = "AndroidSocialNetworks_API_Demos";

    public static final String USER_ID_TWITTER = "2446056205";
    public static final String USER_ID_LINKED_IN = "WQlagxgbbw";

}
