package com.androidsocialnetworks.lib;

public class Consts {

    public static final String TAG = "AndroidSocialNetworks";

}
