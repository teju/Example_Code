package com.androidsocialnetworks.lib;

public class SocialNetworkException extends RuntimeException {
    public SocialNetworkException(String detailMessage) {
        super(detailMessage);
    }
}