package com.androidsocialnetworks.lib;

public class AccessToken {
    public String token;
    public String secret;

    public AccessToken(String token, String secret) {
        this.token = token;
        this.secret = secret;
    }
}
