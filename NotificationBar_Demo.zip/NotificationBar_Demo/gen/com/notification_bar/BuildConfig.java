/** Automatically generated file. DO NOT MODIFY */
package com.notification_bar;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}