To see how to run app : https://www.youtube.com/watch?v=LwK3UAyrXiQ


you can find more info on : https://aboullaite.me/socket-programming-java-swing-android/

have fun !!
