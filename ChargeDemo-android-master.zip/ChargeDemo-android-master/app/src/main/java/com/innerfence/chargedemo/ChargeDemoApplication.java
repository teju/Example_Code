//
// ChargeDemoApplication.java
//
package com.innerfence.chargedemo;

import android.app.Application;

public final class ChargeDemoApplication extends Application
{
    public ChargeDemoApplication()
    {
        super();
    }
}
