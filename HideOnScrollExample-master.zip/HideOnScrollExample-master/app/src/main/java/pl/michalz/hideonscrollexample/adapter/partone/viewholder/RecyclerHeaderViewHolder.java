package pl.michalz.hideonscrollexample.adapter.partone.viewholder;

import android.support.v7.widget.RecyclerView;
import android.view.View;

public class RecyclerHeaderViewHolder extends RecyclerView.ViewHolder {
    public RecyclerHeaderViewHolder(View itemView) {
        super(itemView);
    }
}
