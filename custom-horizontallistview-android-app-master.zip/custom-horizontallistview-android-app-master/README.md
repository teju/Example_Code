# custom-horizontallistview-android-app

The main objective of this blog is to set HorizontalListView widget in your android application.

You can find complete tutorial on how to use the code repo here : [Custom HorizontalListView in Android App](http://www.theappguruz.com/blog/custom-horizontallistview-android-app)

This Tutorial has been presented by The App Guruz - One of the best [Android App Development Company in India](http://www.theappguruz.com/android-app-development/)
