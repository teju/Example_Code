/** Automatically generated file. DO NOT MODIFY */
package com.meetme.android.horizontallistview;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}